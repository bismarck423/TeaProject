package com.tea.trace.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("tea_order")
public class TeaOrder {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String orderNo;
    private Long teaId;
    private String teaName;
    private BigDecimal amount;
    private Integer status; // 0:待支付, 1:成功
    private String payType;
    private LocalDateTime createTime;
}