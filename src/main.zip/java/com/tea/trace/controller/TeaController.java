package com.tea.trace.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.tea.trace.entity.TeaOrder;
import com.tea.trace.entity.TeaProduct;
import com.tea.trace.entity.TeaUser;
import com.tea.trace.mapper.UserMapper;
import com.tea.trace.mapper.TeaMapper;
import com.tea.trace.service.TeaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/tea")
public class TeaController {

    @Autowired
    private TeaService teaService;
    @Autowired
    private TeaMapper teaMapper;
    @Autowired
    private UserMapper userMapper;

    // 获取所有茶叶列表
    @GetMapping("/list")
    public List<TeaProduct> getAllTeas() {
        return teaService.list();
    }

    // 根据溯源码查询茶叶信息
    @GetMapping("/trace/{code}")
    public TeaProduct getByTraceCode(@PathVariable String code) {
        return teaService.lambdaQuery().eq(TeaProduct::getTraceCode, code).one();
    }

    // 在 TeaController 中注入新的 Service（或者直接用 JDBC/MyBatis 演示）
    @PostMapping("/order/create")
    public TeaOrder createOrder(@RequestBody TeaOrder order) {
        order.setOrderNo("TEA" + System.currentTimeMillis());
        order.setStatus(0); // 待支付
        // 这里调用订单服务的 save 方法
        // orderService.save(order);
        return order;
    }

    @PostMapping("/pay/sandbox")
    public String sandboxPay(@RequestParam String orderNo) {
        // 模拟业务逻辑：根据订单号修改状态为 1 (已支付)
        // 根据文档：沙箱支付仅预占库存，不实际扣减
        return "SUCCESS";
    }
    @GetMapping("/admin/users")
    public List<TeaUser> getAllUsers() {
        // 只有管理员可以查询所有用户及其余额
        return userMapper.selectList(null);
    }

    @GetMapping("/user/orders")
    public List<TeaOrder> getMyOrders(HttpSession session) {
        TeaUser user = (TeaUser) session.getAttribute("user");
        return orderMapper.selectList(new LambdaQueryWrapper<TeaOrder>().eq(TeaOrder::getUserId, user.getId()));
    }
}